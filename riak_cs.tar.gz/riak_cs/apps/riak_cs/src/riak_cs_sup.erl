-module(riak_cs_sup).

-behaviour(supervisor).

%% API
-export([start_link/0]).

%% Supervisor callbacks
-export([init/1]).

%% ===================================================================
%% API functions
%% ===================================================================

start_link() ->
    supervisor:start_link({local, ?MODULE}, ?MODULE, []).

%% ===================================================================
%% Supervisor callbacks
%% ===================================================================

init(_Args) ->
   
    Memcached  =  specs ( riak_cs_memcached ,11211 ) , 
    VMaster = { riak_cs_vnode_master,
                  {riak_core_vnode_master, start_link, [riak_cs_vnode]},
                  permanent, 5000, worker, [riak_core_vnode_master]},

    { ok,
        { {one_for_one, 5, 10},
          [Memcached,VMaster]}}.



specs(Mod, Port) ->
    Config = [{ip, {0,0,0,0}},
                 {port, Port}
                 ],
    {Mod,
     {Mod, start, [Config]},
     permanent, 5000, worker, dynamic}.
