-module(riak_cs_memcached).


-export([start/1, stop/0, loop/1 , request/1]).
-define(REQUEST_RECV_TIMEOUT, 2000 ).


stop() ->
    mochiweb_socket_server:stop(?MODULE).

start(Options) ->
    mochiweb_socket_server:start( options() ++Options).

options() ->
    [{name, ?MODULE},
%     {link , false } , 
     {loop, {?MODULE, loop}}].

loop(Socket) ->
%    mochiweb_socket:setopts(Socket, [{active, once}]),
	error_logger:info_msg("enter riak_cs_memcached:loop~n"),
    gen_tcp:controlling_process(Socket,self()),
    request(Socket).

request(Socket) ->
    mochiweb_socket:setopts(Socket, [{active, once},{packet, line}]),
    receive
	{tcp , Socket , Data} ->
		error_logger:info_msg("receving bin:~p",[Data]),
	    	 case dispatch(Socket, string:tokens(binary_to_list(Data), " \r\n"), []) of
        		{reply, DataToSend, _State} ->
		            gen_tcp:send(Socket, DataToSend),
			    request(Socket);
		        {noreply, _State} ->
			    request(Socket);
		        {close, _State} ->
		            mochiweb_socket:close(Socket),
		            exit(normal);
		        {close, DataToSend, _State} ->
		            gen_tcp:send(Socket, DataToSend),
		            mochiweb_socket:close(Socket),
		            exit(normal)
		    end;
        {tcp_closed, _} ->
            mochiweb_socket:close(Socket),
            exit(normal)
    after ?REQUEST_RECV_TIMEOUT*100 ->
        mochiweb_socket:close(Socket),
        exit(normal)
    end.

dispatch(_Socket, ["get", Key], State) ->
    do_get(Key, State, false);
dispatch(_Socket, ["gets", Key], State) ->
    do_get(Key, State, true);

dispatch(Socket, ["set", _Key, _Flags, "0", _Bytes] = Data, State) ->
    inet:setopts(Socket, [{packet, raw}]),
    Result = recv_set_data(Socket, Data, State),
    inet:setopts(Socket, [{packet, line}]),
    Result;

dispatch(_Socket, ["set", _Key, _Flags, _Exptime, _Bytes], State) ->
    {reply, <<"CLIENT_ERROR Exptime must be zero.\r\n">>, State};

dispatch(_Socket, ["delete", _Key], State) ->
  %  case kai_coordinator:route({delete, #data{key=Key}}) of
     case ok of
        ok        -> {reply, <<"DELETED\r\n">>, State};
        undefined -> {reply, <<"NOT_FOUND\r\n">>, State};
        _Other    ->
            send_error_and_close(State, "Failed to delete.")
    end;

dispatch(_Socket, ["delete", Key, "0"], State) ->
    dispatch(_Socket, ["delete", Key], State);
dispatch(_Socket, ["delete", _Key, _Time], State) ->
    {reply, <<"CLIENT_ERROR Time must be zero.\r\n">>, State};

dispatch(_Socket, ["delete", _Key, _Time, "noreply"], State) ->
    {reply, <<"CLIENT_ERROR noreply not supported.\r\n">>, State};

dispatch(_Socket, ["stats"], State) ->
    Response =
        lists:map(
          fun({Name, Value}) ->
                  ["STAT " ++ atom_to_list(Name) ++ " " ++ Value ++ "\r\n"]
          end,
          kai_stat:all()
         ),
    {reply, [Response|"END\r\n"], State};

dispatch(_Socket, ["version"], State) ->
    Version =
        case application:get_key(kai, vsn) of
            {ok, V} -> V;
            _       -> "0"
        end,
    {reply, "VERSION " ++ Version ++ "\r\n", State};

dispatch(_Socket, ["quit"], _State) -> quit;

dispatch(_Socket, _Unknown, State) ->
    {reply, <<"ERROR\r\n">>, State}.

do_get(Key, State, WithCasUnique) ->
    Data = [ { Key , "0" , Key } ] ,
    case Data  of
        Data when is_list(Data) ->
%            {ok, CasUniqueInBinary} = kai_version:cas_unique(Data),
		CasUniqueInBinary = 0 ,	    
            Response = get_response(Data, WithCasUnique, CasUniqueInBinary),
       %     kai_stat:incr_cmd_get(),
       %     kai_stat:add_bytes_read(Data),
            {reply, [Response|"END\r\n"], State};
        undefined ->
            {reply, <<"END\r\n">>, State};
        _Other ->
            send_error_and_close("Failed to read.", State)
    end.

get_response( Data , WithCasUnique, CasUnique) ->
    lists:map(
      fun({Key,Flags,Value}) ->
             % Key = Elem#data.key,
             % Flags = Elem#data.flags,
             % Value = Elem#data.value,
		error_logger:info_msg("Key=~p,Flags=~p,Value=~p~n",[Key,Flags,Value]),
              [
               io_lib:format("VALUE ~s ~s ~w", [Key, Flags, byte_size( list_to_binary(Value))]),
               case WithCasUnique of
                   true ->
                       io_lib:format(" ~w", [cas_unique(CasUnique)]);
                   _ -> []
               end,
               "\r\n", Value, "\r\n"]
      end, Data).

recv_set_data(_Socket, ["set", _Key, _Flags, "0", _Bytes], State) ->
	{noreply , State}.
%    case gen_tcp:recv(Socket, list_to_integer(Bytes), ?REQUEST_RECV_TIMEOUT) of
%        {ok, Value} ->
%            gen_tcp:recv(Socket, 2, ?REQUEST_RECV_TIMEOUT),
%            case kai_coordinator:route(
%                {put, #data{key=Key, flags=Flags, value=Value}}
%            ) of
%                ok ->
%                    gen_tcp:send(Socket, <<"STORED\r\n">>),
%                    kai_stat:incr_cmd_set(),
%                    kai_stat:add_bytes_write(#data{value=Value}),
%                    {noreply, State};
%                _Other ->
%                    send_error_and_close("Failed to write.", State)
%            end;
%        _Other ->
%            {noreply, State}
%    end.

send_error_and_close(Message, State) ->
    %?warning(io_lib:format("send_error_and_close/2: ~p", [Message])),
    {close, ["SERVER_ERROR ", Message, "\r\n"], State}.

cas_unique(CasUniqueInBinary) ->
    <<HashedValue:64/integer>> = CasUniqueInBinary,
    HashedValue.
